export interface ProductoPedidoInterface {
    producto_id: number;
    cantidad: number;
    precio: number;
}