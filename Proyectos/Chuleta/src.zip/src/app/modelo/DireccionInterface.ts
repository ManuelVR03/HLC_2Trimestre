export interface DireccionInterface {
    calle: string;
    numero: number;
    ciudad: string;
    pais: string;
}