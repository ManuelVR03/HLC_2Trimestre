import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Storage } from '@ionic/storage-angular';
import { Usuario } from '../modelo/Usuario';
import { Producto } from '../modelo/Producto';
import { Pedido } from '../modelo/Pedido';
import { Direccion } from '../modelo/Direccion';
import { ProductoPedido } from '../modelo/ProductoPedido';

@Component({
  selector: 'app-detalles',
  templateUrl: './detalles.page.html',
  styleUrls: ['./detalles.page.scss'],
  standalone: false,
})
export class DetallesPage implements OnInit {

  objeto: any = {};

  usuario?: Usuario;

  producto?: Producto;

  pedido?: Pedido;

  storageTipo: string = "";

  constructor(

    private storage: Storage,

    private route: ActivatedRoute

  ) {

    this.route.queryParams.subscribe(params => {

      if (params['objeto']) {

        this.objeto = JSON.parse(params['objeto']);

        if (this.storageTipo == 'usuarios') {

          this.usuario = this.objeto as Usuario;

        }else if (this.storageTipo == 'productos') {

          this.producto = this.objeto as Producto;

        }else {

          this.pedido = this.objeto as Pedido;

        }

      }

    });

   }

  async ngOnInit(): Promise<void> {

    await this.storage.create();

    this.storage.get('storageType').then((value: any) => {

      this.storageTipo = value

    });

  }

}
