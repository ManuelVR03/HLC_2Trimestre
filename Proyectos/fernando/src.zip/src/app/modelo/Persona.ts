export class Persona{

    constructor(
        public id:number,
        public nombre:string,
        public apellido1:string,
        public dni:string,
        public fechaNacimiento: Date,
        public pasatiempo:string[],
        
    ){}

}