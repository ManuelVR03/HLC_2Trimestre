export interface EquipoInterface {
    nombre: string;
    entrenador: string;
    estadio: string;
    anio_fundacion: number;
    puntos: number;
    ciudad: string;
    jugadores: string[];
}