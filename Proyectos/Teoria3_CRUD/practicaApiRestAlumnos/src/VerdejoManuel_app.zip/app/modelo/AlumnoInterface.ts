export interface AlumnoInterface {
    id: number;
    gender: string;
        first_name: string;
        last_name: string;
        email: string;
        avatar: string;
        address: string;
        city: string;
        postalCode: string;
    }
    